# Instructions complètes pour Lovable — Terex Automatisation USDT

## Vue d'ensemble

L'objectif est d'automatiser 100% l'envoi USDT dès que Naboopay confirme
la réception du paiement Orange Money ou Wave du client.

Flux complet :
  Client paie (Orange Money / Wave)
        ↓
  Naboopay détecte le paiement
        ↓
  Naboopay envoie un webhook à Terex
        ↓
  Edge Function "naboopay-webhook" reçoit
        ↓
  Vérifie la signature + le montant
        ↓
  Appelle l'API Binance
        ↓
  USDT envoyés au wallet du client
        ↓
  Statut "completed" + email client


## Fichiers à créer

### 1. supabase/functions/naboopay-webhook/index.ts
→ Copier le contenu du fichier naboopay-webhook/index.ts fourni

### 2. supabase/functions/send-usdt/index.ts
→ Copier le contenu du fichier send-usdt/index.ts fourni
→ Sert de fallback manuel depuis le dashboard admin


## Secrets Supabase à configurer
(Supabase → Settings → Edge Functions → Secrets)

  BINANCE_API_KEY           = clé API Binance de l'admin
  BINANCE_SECRET_KEY        = clé secrète Binance de l'admin
  NABOOPAY_WEBHOOK_SECRET   = secret webhook Naboopay (dans dashboard Naboopay)


## URL du webhook à configurer dans Naboopay

Dans le dashboard Naboopay, configurer l'URL webhook :
  https://[TON-PROJECT-ID].supabase.co/functions/v1/naboopay-webhook

⚠️  L'admin doit remplacer [TON-PROJECT-ID] par son vrai ID Supabase


## Modification importante lors de la création d'une commande

Quand un client confirme sa commande et choisit de payer via Naboopay,
il faut passer l'orderId Terex à Naboopay dans le champ "reference" :

  // Dans la création de transaction Naboopay
  const transaction = await createNaboopayTransaction({
    amount: order.amount,
    currency: "XOF",
    reference: order.id,   // ← CRUCIAL : l'orderId Terex
    description: `Achat USDT - Terex`,
    callback_url: "https://[TON-PROJECT].supabase.co/functions/v1/naboopay-webhook",
  })

⚠️  Vérifie le nom exact du champ dans la doc Naboopay
    (parfois "reference", "external_id", "metadata", ou "order_id")


## Modification du dashboard admin

Ajouter un bouton "Envoyer USDT manuellement" sur les commandes
dont le statut est "pending" ou "processing" (fallback si webhook raté) :

  const sendManually = async (orderId) => {
    const { data, error } = await supabase.functions.invoke('send-usdt', {
      body: { orderId }
    })
    if (error) toast({ title: 'Erreur', description: error.message, variant: 'destructive' })
    else toast({ title: '✅ USDT envoyés', description: `Binance ID: ${data.withdrawalId}` })
  }


## Mapping des réseaux (déjà dans le code)

  TRC20   → TRX   (Tron)
  BEP20   → BSC   (Binance Smart Chain)
  ERC20   → ETH   (Ethereum)
  POLYGON → MATIC
  SOLANA  → SOL
  APTOS   → APT


## Points à vérifier avec la doc Naboopay

Le code contient des commentaires ⚠️  sur les points à adapter :

1. Nom du header de signature (actuellement "x-naboopay-signature")
2. Nom de l'événement de paiement réussi (actuellement ["transaction.paid", "payment.completed", "paid", "success"])
3. Champ contenant la référence de commande dans le payload
4. Champ contenant le montant dans le payload

Ces 4 points sont à confirmer dans la doc officielle Naboopay.


## Comportement en cas d'erreur

Si Binance échoue après réception du paiement Naboopay :
- La commande repasse en statut "pending"
- Une note est ajoutée avec le message d'erreur
- L'admin voit la commande dans le dashboard et peut renvoyer manuellement
- Naboopay reçoit un 200 (pour ne pas réessayer le webhook)
