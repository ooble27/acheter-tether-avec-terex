// supabase/functions/send-usdt/index.ts
// Edge Function Terex — Envoi manuel USDT via Binance (fallback depuis dashboard admin)
// Utilisé quand le webhook Naboopay n'a pas fonctionné, ou pour les cas particuliers

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { crypto } from "https://deno.land/std@0.168.0/crypto/mod.ts";

async function signBinance(queryString: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(queryString));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

const NETWORK_MAP: Record<string, string> = {
  TRC20: "TRX", BEP20: "BSC", ERC20: "ETH",
  POLYGON: "MATIC", SOLANA: "SOL", APTOS: "APT",
};

async function sendViaBinance(walletAddress: string, network: string, amount: number): Promise<string> {
  const API_KEY    = Deno.env.get("BINANCE_API_KEY")!;
  const API_SECRET = Deno.env.get("BINANCE_SECRET_KEY")!;
  const binanceNetwork = NETWORK_MAP[network.toUpperCase()];
  if (!binanceNetwork) throw new Error(`Réseau non supporté : ${network}`);
  const timestamp = Date.now();
  const params = `coin=USDT&network=${binanceNetwork}&address=${walletAddress}&amount=${amount}&timestamp=${timestamp}`;
  const signature = await signBinance(params, API_SECRET);
  const response = await fetch("https://api.binance.com/sapi/v1/capital/withdraw/apply", {
    method: "POST",
    headers: { "X-MBX-APIKEY": API_KEY, "Content-Type": "application/x-www-form-urlencoded" },
    body: `${params}&signature=${signature}`,
  });
  const data = await response.json();
  if (!response.ok || data.code) throw new Error(`Binance: ${data.msg || JSON.stringify(data)}`);
  return data.id;
}

serve(async (req) => {
  try {
    const { orderId } = await req.json();
    if (!orderId) return new Response(JSON.stringify({ error: "orderId manquant" }), { status: 400 });

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: order, error } = await supabase.from("orders").select("*").eq("id", orderId).single();

    if (error || !order) return new Response(JSON.stringify({ error: "Commande introuvable" }), { status: 404 });
    if (order.status === "completed") return new Response(JSON.stringify({ error: "Déjà complétée" }), { status: 400 });
    if (!order.wallet_address) return new Response(JSON.stringify({ error: "Adresse wallet manquante" }), { status: 400 });

    await supabase.from("orders").update({ status: "processing" }).eq("id", orderId);

    const withdrawalId = await sendViaBinance(order.wallet_address, order.network, order.usdt_amount);

    await supabase.from("orders").update({
      status: "completed",
      processed_at: new Date().toISOString(),
      notes: `Envoi manuel | Binance ID: ${withdrawalId} | Réseau: ${order.network}`,
    }).eq("id", orderId);

    return new Response(JSON.stringify({ success: true, withdrawalId }), { status: 200 });

  } catch (err: any) {
    console.error("Erreur send-usdt:", err);
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
});
