// supabase/functions/naboopay-webhook/index.ts
// Edge Function Terex — Reçoit le webhook Naboopay et envoie automatiquement les USDT via Binance

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { crypto } from "https://deno.land/std@0.168.0/crypto/mod.ts";

// ─── VÉRIFICATION SIGNATURE NABOOPAY ─────────────────────────────
// Naboopay signe ses webhooks pour prouver qu'ils viennent bien d'eux
// À vérifier dans ta doc Naboopay : le nom exact du header (ici "x-naboopay-signature")
async function verifyNaboopaySignature(
  body: string,
  signature: string,
  secret: string
): Promise<boolean> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(body)
  );
  const expected = Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  // Comparer de façon sécurisée (évite les timing attacks)
  return expected === signature.replace("sha256=", "");
}

// ─── SIGNATURE BINANCE ────────────────────────────────────────────
async function signBinance(queryString: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(queryString)
  );
  return Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// ─── MAPPING RÉSEAU TEREX → BINANCE ──────────────────────────────
const NETWORK_MAP: Record<string, string> = {
  TRC20:   "TRX",
  BEP20:   "BSC",
  ERC20:   "ETH",
  POLYGON: "MATIC",
  SOLANA:  "SOL",
  APTOS:   "APT",
};

// ─── ENVOI USDT VIA BINANCE ───────────────────────────────────────
async function sendViBinance(
  walletAddress: string,
  network: string,
  amount: number
): Promise<string> {
  const API_KEY    = Deno.env.get("BINANCE_API_KEY")!;
  const API_SECRET = Deno.env.get("BINANCE_SECRET_KEY")!;

  const binanceNetwork = NETWORK_MAP[network.toUpperCase()];
  if (!binanceNetwork) throw new Error(`Réseau non supporté : ${network}`);

  const timestamp = Date.now();
  const params = [
    `coin=USDT`,
    `network=${binanceNetwork}`,
    `address=${walletAddress}`,
    `amount=${amount}`,
    `timestamp=${timestamp}`,
  ].join("&");

  const signature = await signBinance(params, API_SECRET);

  const response = await fetch(
    "https://api.binance.com/sapi/v1/capital/withdraw/apply",
    {
      method: "POST",
      headers: {
        "X-MBX-APIKEY": API_KEY,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `${params}&signature=${signature}`,
    }
  );

  const data = await response.json();
  if (!response.ok || data.code) {
    throw new Error(`Binance erreur: ${data.msg || JSON.stringify(data)}`);
  }

  return data.id; // Binance withdrawal ID
}

// ─── HANDLER PRINCIPAL ────────────────────────────────────────────
serve(async (req) => {

  // 1. Lire le body brut (nécessaire pour vérifier la signature)
  const rawBody = await req.text();

  // 2. Vérifier la signature Naboopay
  // ⚠️  Vérifie dans ta doc Naboopay le nom exact du header de signature
  const signature = req.headers.get("x-naboopay-signature") || "";
  const webhookSecret = Deno.env.get("NABOOPAY_WEBHOOK_SECRET") || "";

  if (webhookSecret) {
    const valid = await verifyNaboopaySignature(rawBody, signature, webhookSecret);
    if (!valid) {
      console.error("Signature Naboopay invalide — requête rejetée");
      return new Response("Unauthorized", { status: 401 });
    }
  }

  // 3. Parser le payload Naboopay
  // ⚠️  Adapte les noms des champs selon la doc Naboopay :
  //     - event : le type d'événement (ex: "transaction.paid", "payment.completed"...)
  //     - transaction.reference : la référence de commande Terex
  //     - transaction.amount : le montant payé
  //     - transaction.status : le statut
  let payload: any;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }

  console.log("Webhook Naboopay reçu:", JSON.stringify(payload));

  // 4. Ne traiter que les paiements confirmés
  // ⚠️  Vérifie dans ta doc Naboopay le nom exact de l'événement de paiement réussi
  const event = payload.event || payload.type || payload.status;
  const PAID_EVENTS = ["transaction.paid", "payment.completed", "paid", "success"];

  if (!PAID_EVENTS.includes(event)) {
    console.log(`Événement ignoré: ${event}`);
    // Retourner 200 quand même pour que Naboopay ne réessaie pas
    return new Response("OK - événement ignoré", { status: 200 });
  }

  // 5. Extraire la référence de commande Terex
  // ⚠️  Quand tu crées une transaction Naboopay, passe l'orderId Terex dans
  //     le champ "reference" ou "metadata" — c'est ce qu'on récupère ici
  const orderId =
    payload.reference ||
    payload.data?.reference ||
    payload.transaction?.reference ||
    payload.metadata?.order_id;

  if (!orderId) {
    console.error("Pas d'orderId trouvé dans le payload Naboopay");
    return new Response("orderId manquant", { status: 400 });
  }

  // 6. Connexion Supabase
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  // 7. Récupérer la commande Terex
  const { data: order, error: orderError } = await supabase
    .from("orders")
    .select("*")
    .eq("id", orderId)
    .single();

  if (orderError || !order) {
    console.error("Commande introuvable:", orderId);
    return new Response("Commande introuvable", { status: 404 });
  }

  // 8. Vérifications de sécurité
  if (order.status === "completed") {
    console.log("Commande déjà traitée — doublon ignoré:", orderId);
    return new Response("Déjà traité", { status: 200 });
  }
  if (!order.wallet_address) {
    console.error("Adresse wallet manquante pour commande:", orderId);
    return new Response("Wallet manquant", { status: 400 });
  }

  // 9. Vérifier que le montant Naboopay correspond à la commande
  // ⚠️  Adapte selon le format de montant dans le payload Naboopay
  const paidAmount =
    payload.amount ||
    payload.data?.amount ||
    payload.transaction?.amount;

  // Tolérance de 1 CFA pour les arrondis
  if (paidAmount && Math.abs(paidAmount - order.amount) > 1) {
    console.error(`Montant incorrect: reçu ${paidAmount}, attendu ${order.amount}`);
    await supabase.from("orders").update({
      status: "failed",
      notes: `Montant incorrect: reçu ${paidAmount} CFA, attendu ${order.amount} CFA`,
    }).eq("id", orderId);
    return new Response("Montant incorrect", { status: 400 });
  }

  // 10. Passer en "processing"
  await supabase
    .from("orders")
    .update({ status: "processing" })
    .eq("id", orderId);

  // 11. Envoyer les USDT via Binance
  try {
    const withdrawalId = await sendViBinance(
      order.wallet_address,
      order.network,
      order.usdt_amount
    );

    // 12. Mettre à jour le statut final
    await supabase
      .from("orders")
      .update({
        status: "completed",
        processed_at: new Date().toISOString(),
        notes: `Auto-envoi OK | Binance withdrawal ID: ${withdrawalId} | Réseau: ${order.network}`,
      })
      .eq("id", orderId);

    console.log(`✅ USDT envoyés avec succès - Order: ${orderId} - Binance ID: ${withdrawalId}`);

    return new Response(
      JSON.stringify({ success: true, withdrawalId }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );

  } catch (sendError: any) {
    // En cas d'erreur d'envoi, logger et remettre en pending pour intervention manuelle
    console.error("Erreur envoi Binance:", sendError.message);

    await supabase
      .from("orders")
      .update({
        status: "pending",
        notes: `Paiement reçu mais erreur envoi Binance: ${sendError.message}`,
      })
      .eq("id", orderId);

    // Retourner 200 pour éviter que Naboopay réessaie (le paiement est bien reçu)
    return new Response(
      JSON.stringify({ received: true, error: sendError.message }),
      { status: 200 }
    );
  }
});
